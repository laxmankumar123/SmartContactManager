
console.log("this is script starts");
//const toggleSidebar=()=>{
//  if($('.sidebar').is(".visible")){
//      //true
//      //band krana h
//      $(".sidebar").css("display", none);
//      $(".content").css("margin-left","0%");
//  }
//  else{
//      //false
//      //show krana h

//      $(".sidebar").css("display", "block");
//      $(".content").css("margin-left","20%");
     
//  }
//};

function toggleSidebar() {
 console.log("----------s");
 if($(".sidebar").is(":visible")){
     //true
     console.log("----------sss");
     //band krana h
     $(".sidebar").css("display", "none");
     $(".content").css("margin-left","0%");
 }
 else{
     //false
     //show krana h

     $(".sidebar").css("display", "block");
     $(".content").css("margin-left","20%");
     
 }
 console.log("----------e");
}

console.log("this is script end ");
	