package com.smart.service;

import java.util.Properties;

//import javax.mail.Authenticator;
//import javax.mail.Message;
//import javax.mail.PasswordAuthentication;
//import javax.mail.Session;
//import javax.mail.Transport;
//import javax.mail.internet.InternetAddress;
//import javax.mail.internet.MimeMessage;

import org.springframework.stereotype.Service;



//===
import javax.mail.*;
import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
//import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

@Service
public class EmailService {
	
	public boolean sendEmail(String subject, String message, String to) {
		boolean f=false;
		System.out.println("---f"+f);

		// variabe for gmil
		String from = "laxmankumar0071997@gmail.com";
		String host = "smtp.gmail.com";
		// get the systemm properties
		Properties properties = System.getProperties();
		System.out.println("PROPERTIES" + properties);
		// host set
		properties.put("mail.smtp.host", host);
		properties.put("mail.smtp.port", "465");
		properties.put("mail.smtp.ssl.enable", "true");
		properties.put("mail.smtp.auth", "true");
		// step 1 to get the session object..
		System.out.println("--prope--put"+properties);
		
		
		Session session = Session.getInstance(properties, new Authenticator() {
			@Override
			protected PasswordAuthentication getPasswordAuthentication() {
				// TODO Auto-generated method stub
				System.out.println("===44=======");
				return new PasswordAuthentication("laxman@strategicerp.com", "Erp@laxkoli8525");
			}
		});
		
		
		System.out.println("--sesion---45"+ session);
		// step 2 compose the message [text, multo med]
		session.setDebug(true);
		MimeMessage m = new MimeMessage(session);
		// from email
		System.out.println("-------ses--"+session);
		System.out.println("-------m--"+m);
		try {
			// from email
			System.out.println("---m---54"+m);
			m.setFrom(from);
			// adding recipient to message
			m.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
			// add sub
			m.setSubject(subject);
			// addimg text to meg
			m.setText(message);
			// step 3 send to mesg using tranpose class
			System.out.println("----63--m"+m);
			Transport.send(m);
			System.out.println("---65---m=="+m);
			System.out.println("sent successfully ");
			f=true;
		} catch (Exception e) {
			System.out.println("----66 catch-----");
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		System.out.println("----69--");
		return f;
	}

}
