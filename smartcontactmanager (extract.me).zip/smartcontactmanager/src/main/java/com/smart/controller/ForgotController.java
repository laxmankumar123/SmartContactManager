package com.smart.controller;

import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.smart.service.EmailService;

import jakarta.servlet.http.HttpSession;

@Controller
public class ForgotController {
	@Autowired
	private EmailService emailService;
	
	Random random = new Random();
	// email idform open handler
	@RequestMapping("forgot")
	public String openEmailFom() {
		
		return "forgot_email_form";
		
	}
	
	
	// @{/send-otp} handler
	
	@PostMapping("/send-otp")
	public String sendOTP(@RequestParam("email") String email
			,HttpSession session) {
		
		System.out.println("--email"+email);
		
		//generate otp of 4 digit
		
		
		int otp = random.nextInt(999999);
		System.out.println("====otp==="+ otp);
		
		
		// write code for send otp to email...
		String subject="OTP From SCM";
		String  message="<h1> OTP="+otp+"</h1>";
		String  to=email;
		System.out.println("----sub"+subject);
		System.out.println("----mess"+message);
		System.out.println("----to"+to);
		
		boolean flag = this.emailService.sendEmail(subject, message, to);
		
		System.out.println("----flag"+flag);
		if(flag) {
			System.out.println("----flag inside"+flag);
			return "verify_otp";
		}
		else {
			System.out.println("----else block--");
			session.setAttribute("message","please check your email id we sent opt");
			return "forgot_email_form";
		}
		
		
	}

}
