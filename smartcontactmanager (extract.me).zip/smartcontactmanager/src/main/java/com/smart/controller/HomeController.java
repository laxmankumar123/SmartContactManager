package com.smart.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
//import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
//import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.smart.dao.UserRepository;
import com.smart.entities.User;
import com.smart.helper.Message;

import jakarta.servlet.http.HttpSession;


@Controller
public class HomeController {
	
	@Autowired
	private BCryptPasswordEncoder passwordEncoder;
	@Autowired
	private UserRepository userRepository;
	
	@RequestMapping("/")
	public String home( Model model ) {
		model.addAttribute("title", "home page -smaart contact man");
		return "home";
	}
	
	@RequestMapping("/home")
	public String homes( Model model ) {
		model.addAttribute("title", "home page -smaart contact man");
		return "home";
	}
	
	@RequestMapping("/about")
	public String about( Model model ) {
		model.addAttribute("title", "aboutt page -smaart contact man");
		return "about";
		
	}
	
	
	@RequestMapping( value = "/signup/", method = RequestMethod.GET)
	public String signup( Model model ) {
		model.addAttribute("title", "Register page -smaart contact man");
		model.addAttribute("user", new User());
		return "signup";
		
	}
	
	@RequestMapping(value = "/do_register", method = RequestMethod.POST)	
	public String registerUser( @Valid @ModelAttribute("user") User user, BindingResult result1, 
			@RequestParam(value = "agreement",defaultValue = "false") boolean agreement, 
			Model model, HttpSession session ) {
		System.out.println("KOLIS");

		try {
			if(!agreement) {
				System.out.println("====You have not agreed terms and condition===");
				throw new Exception("You have not agreed terms....before submit please click on check box");
			}
			if(result1.hasErrors()) {
				
				System.out.println("=======hasErrors bolck========="+ result1.toString());
				model.addAttribute("user", user);
				return "signup";
			}
			

			user.setRole("ROLE_USER");
			user.setEnabled(true);
			user.setImageurl("default.png");
			user.setPassword(passwordEncoder.encode(user.getPassword()));
			
			System.out.println("agreement"+agreement);
			System.out.println("User========================TRY"+user);
			User result = this.userRepository.save(user);
		    model.addAttribute("user", result);
		    model.addAttribute("user", new User());
			System.out.println("session==============------------=========="+session);
		    session.setAttribute("message", new Message("successful Registration !!", "alert-success"));
			return "signup";
		} catch (Exception e) {
			model.addAttribute("user", user);
			System.out.println("User======================== CATCHS"+user);
			System.out.println("session==============------------=========="+session);

			session.setAttribute("message", new Message("Something went wrong .!!"+e.getMessage(), "alert-danger"));
			
			//System.out.println("---------message.session"+message.session);
			return "signup";	
		}
	    
	    


		
		//model.addAttribute("title", "Register page -smaart contact man");
		//model.addAttribute("user", new User());
	    
		
		
	}
	
//
//	@RequestMapping(value = "/do_register", method = RequestMethod.POST)	
//	public String registerUser1( @Valid @ModelAttribute("user") User user, BindingResult result1, 
//			@RequestParam(value = "agreement",defaultValue = "false") boolean agreement, 
//			Model model, HttpSession session ) {
//		System.out.println("KOLIS");
//
//		try {
//			if(!agreement) {
//				System.out.println("You have not agreed terms and condition");
//				throw new Exception("you have not agreed terms...");
//			}
//			if(result1.hasErrors()) {
//				
//				System.out.println(result1.toString());
//				model.addAttribute("user", new User());
//				return "signup";
//			}
//			
//
//			user.setRole("ROLE_USER");
//			user.setEnabled(true);
//			user.setImageurl("default.png");
//			//user.setPassword(passwordEncoder.encode(user.getPassword()));
//			
//			System.out.println("agreement"+agreement);
//			System.out.println("User========================TRY"+user);
//			User result = this.userRepository.save(user);
//		    model.addAttribute("user", result);
//		    model.addAttribute("user", new User());
//			System.out.println("session==============------------=========="+session);
//		    session.setAttribute("message", new Message("successful Registration !!", "alert-success"));
//			return "signup";
//		} catch (Exception e) {
//			model.addAttribute("user", user);
//			System.out.println("User======================== CATCHS"+user);
//			System.out.println("session==============------------=========="+session);
//
//			session.setAttribute("message", new Message("Something went wrong .!!"+e.getMessage(), "alert-danger"));
//			
//			//System.out.println("---------message.session"+message.session);
//			return "signup";	
//		}
	    
	    


		
		//model.addAttribute("title", "Register page -smaart contact man");
		//model.addAttribute("user", new User());
	    
		
		
//	}
	
	@RequestMapping(value = "/signin", method = {RequestMethod.GET,RequestMethod.POST})	
	public String customLogin(Model m) {
		m.addAttribute("tittle", "Login page");
		return "login";
	}
	//HttpSession session = request.getSession();

	//, HttpServletRequest request, HttpServletResponse response)  throws ServletException, IOException

	
//	@Autowired
//	private UserRepository userRepository; 
//	@GetMapping("/test")
//	@ResponseBody
//	public String test() {
//		User user = new User();
//		user.setName("laxman");
//		user.setEmail("lax");
//		userRepository.save(user);
//		
//		return "working";
//	}

}
