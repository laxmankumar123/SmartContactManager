
package com.smart.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityCustomizer;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

@Configuration

@EnableWebSecurity

@EnableWebMvc // @EnableGlobalMethodSecurity(prePostEnabled = true) public
class MyConfig {

	@Bean
	protected UserDetailsService getUserDetailsService() {
		return new UserDetalsServiceImpl();
	}

	@Bean
	protected BCryptPasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}

	//@Bean
	//protected WebSecurityCustomizer webSecurityCustomizerjt() {
		//return (web) -> web.ignoring().requestMatchers("/resources/**", "/static/**", "/css/**", "/js/**", "/images/**", "/error", "/dist/**");
		//web.ignoring().requestMatchers("/signup/" );
	//}

	//"/","/signin", "/img/**", "/Css/style.css",  "/static/**"
	@Bean
	protected SecurityFilterChain filterChain1(HttpSecurity http) throws Exception {
		http.authorizeHttpRequests()
				.requestMatchers( "/admin/**").hasRole("ADMIN")
				.requestMatchers("/user/**").hasRole("USER")
				.requestMatchers("/**")
				.permitAll()
				.and().formLogin()
				.loginPage("/signin")
				.loginProcessingUrl("/dologin")
				.defaultSuccessUrl("/user/index")
				.and().csrf().disable();
		
		
		return http.build();
	}

	@Bean
	protected AuthenticationManager authenticationManager(AuthenticationConfiguration configuration) throws Exception {
		return configuration.getAuthenticationManager();
	}

	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
		auth.authenticationProvider(authenticationProvider());
	}

	@Bean 
	
	protected DaoAuthenticationProvider authenticationProvider() {
  DaoAuthenticationProvider daoAuthenticationProvider = new
  DaoAuthenticationProvider();
  daoAuthenticationProvider.setUserDetailsService(this.getUserDetailsService())
  ; daoAuthenticationProvider.setPasswordEncoder(passwordEncoder()); return
  daoAuthenticationProvider;
  }

	

}